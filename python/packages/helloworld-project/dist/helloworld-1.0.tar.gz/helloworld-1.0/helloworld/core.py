def get_message():
    return "Hello world!"


def print_message():
    print(get_message)
